package tn.esprit.gestionzoo.interfaces;

public interface Carnivore<T> {

    void eatMeat(T meat);
}
