package tn.esprit.gestionzoo.interfaces;

public interface Herbivore<T> {

    void eatPlants(T plant);
}
