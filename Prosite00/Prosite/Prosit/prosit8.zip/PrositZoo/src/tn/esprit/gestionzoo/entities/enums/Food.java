package tn.esprit.gestionzoo.entities.enums;

public enum Food {PLANTS, MEAT, BOTH}

